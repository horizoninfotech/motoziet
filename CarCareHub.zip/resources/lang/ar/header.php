<?php

return [
    'home' => 'الصفحة الرئيسية',
    'services' => 'الخدمات',
    'packages' => 'الباقات',
    'about_us' => 'معلومات عنا',
    'contact_us' => 'اتصل بنا',
    'login_register' => 'تسجيل الدخول / التسجيل',
    'get_support' => 'الحصول على الدعم',
    'my_account' => 'حسابي',
    'wishlist' => 'قائمة الرغبات',
    'shopping_cart' => 'عربة التسوق',
    'cart' => 'عربة التسوق',
    'subtotal' => 'المجموع الفرعي',
    'view_cart' => 'عرض عربة التسوق',
    'checkout' => 'الدفع',
    'free_shipping' => 'شحن مجاني على جميع الطلبات التي تزيد عن 100 دولار!',
];
