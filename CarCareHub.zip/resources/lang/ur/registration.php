<?php 
return [
    'title' => 'کمپنی کی رجسٹریشن',
    'name' => 'کمپنی کا نام',
    'email' => 'ای میل',
    'mobile' => 'موبائل',
    'registration_tax_number' => 'رجسٹریشن ٹیکس نمبر',
    'country' => 'ملک منتخب کریں',
    'state' => 'صوبہ',
    'city' => 'شہر',
    'password' => 'پاس ورڈ',
    'password_confirmation' => 'پاس ورڈ کی تصدیق کریں',
    'register' => 'رجسٹر کریں',
];