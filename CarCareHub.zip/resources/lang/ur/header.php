<?php

return [
    'home' => 'ہوم',
    'services' => 'خدمات',
    'packages' => 'پیکجز',
    'about_us' => 'ہمارے بارے میں',
    'contact_us' => 'ہم سے رابطہ کریں',
    'login_register' => 'لاگ ان / رجسٹر',
    'get_support' => 'مدد حاصل کریں',
    'my_account' => 'میرا اکاؤنٹ',
    'wishlist' => 'خواہشات کی فہرست',
    'shopping_cart' => 'شاپنگ کارٹ',
    'cart' => 'کارٹ',
    'subtotal' => 'کل',
    'view_cart' => 'کارٹ دیکھیں',
    'checkout' => 'چیک آؤٹ',
    'free_shipping' => 'تمام آرڈرز پر $100 سے زیادہ مفت شپنگ!',
];
