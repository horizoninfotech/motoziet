

<?php $__env->startSection('title', 'Edit Service'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Edit Service</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('admin.services.update', $service->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="title">Title (English)</label>
            <input type="text" name="title" class="form-control" id="title" value="<?php echo e($service->title); ?>" required>
        </div>
        <div class="form-group">
            <label for="title_ar">Title (Arabic)</label>
            <input type="text" name="title_ar" class="form-control" id="title_ar" value="<?php echo e($service->title_ar); ?>" required>
        </div>
        <div class="form-group">
            <label for="title_ur">Title (Urdu)</label>
            <input type="text" name="title_ur" class="form-control" id="title_ur" value="<?php echo e($service->title_ur); ?>" required>
        </div>
        <div class="form-group">
            <label for="description">Description (English)</label>
            <textarea name="description" class="form-control" id="description" required><?php echo e($service->description); ?></textarea>
        </div>
        <div class="form-group">
            <label for="description_ar">Description (Arabic)</label>
            <textarea name="description_ar" class="form-control" id="description_ar" required><?php echo e($service->description_ar); ?></textarea>
        </div>
        <div class="form-group">
            <label for="description_ur">Description (Urdu)</label>
            <textarea name="description_ur" class="form-control" id="description_ur" required><?php echo e($service->description_ur); ?></textarea>
        </div>
        <div class="form-group">
            <label for="category_id">Category</label>
            <select name="category_id" id="category_id" class="form-control" required>
                <option value="0" disabled <?php echo e(old('category_id', $service->category_id ?? 0) == 0 ? 'selected' : ''); ?>>Please select a category</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>" <?php echo e(old('category_id', $service->category_id ?? '') == $category->id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        
        <div class="form-group">
            <label for="icon">Icon</label>
            <input type="file" name="icon" class="form-control-file" id="icon">
            <small class="form-text text-muted">Leave blank to keep the current icon.</small>
        </div>
        <?php if($service->icon): ?>
            <div class="form-group">
                <label>Current Icon</label>
                <br>
                <img src="<?php echo e(asset('images/icons/' . $service->icon)); ?>" alt="Icon" width="100">
            </div>
        <?php endif; ?>
        <button type="submit" class="btn btn-primary">Update Service</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\CarCareHub\resources\views/admin/services/edit.blade.php ENDPATH**/ ?>