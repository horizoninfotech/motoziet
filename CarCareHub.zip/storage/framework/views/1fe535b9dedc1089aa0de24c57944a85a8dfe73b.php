

<?php $__env->startSection('title', 'Edit Package'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Edit Package</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('admin.packages.update', $package->id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="form-group">
        <label for="name">Name</label>
        <input type="text" name="name" class="form-control" id="name" value="<?php echo e($package->name); ?>" required>
    </div>
    <div class="form-group">
        <label for="description">Description</label>
        <textarea name="description" class="form-control" id="description"><?php echo e($package->description); ?></textarea>
    </div>
    <div class="form-group">
        <label for="price">Price</label>
        <input type="number" name="price" class="form-control" id="price" value="<?php echo e($package->price); ?>" required>
    </div>
    <div class="form-group">
        <label for="image">Image</label>
        <input type="file" name="image" class="form-control-file" id="image">
        <small class="form-text text-muted">Leave blank to keep the current image.</small>
    </div>
    <?php if($package->image): ?>
        <div class="form-group">
            <label>Current Image</label>
            <br>
            <img src="<?php echo e(asset('images/packages/' . $package->image)); ?>" alt="Image" width="100">
        </div>
    <?php endif; ?>
    <button type="submit" class="btn btn-primary">Update Package</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\CarCareHub\resources\views/admin/packages/edit.blade.php ENDPATH**/ ?>