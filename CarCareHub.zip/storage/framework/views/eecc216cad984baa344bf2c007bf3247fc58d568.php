

<?php $__env->startSection('title', __('registration.title')); ?>

<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('css/company-registration.css')); ?>" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />

<style>
    #map {
        height: 300px;
        width: 100%;
        margin-bottom: 20px;
    }

    /* Style for input icons */
    .input-icon {
        position: relative;
    }

    .input-icon input,
    .input-icon select {
        padding-left: 40px;
    }

    .input-icon .fa {
        position: absolute;
        left: 10px;
        top: 50%;
        transform: translateY(-50%);
        font-size: 18px;
        color: red;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container company-registration">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h3 class="mb-0"><?php echo e(__('registration.title')); ?></h3>
                </div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('company.submitRegistration')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group pb-3 input-icon">
                            <i class="fas fa-building"></i>
                            <input type="text" name="name" id="name" class="form-control" placeholder="<?php echo e(__('registration.name')); ?>" required>
                        </div>
                        <div class="form-group pb-3 input-icon">
                            <i class="fas fa-envelope"></i>
                            <input type="email" name="email" id="email" class="form-control" placeholder="<?php echo e(__('registration.email')); ?>" required>
                        </div>

                        <div class="form-group pb-3 input-icon">
                            <i class="fas fa-file-alt"></i>
                            <input type="text" name="registration_tax_number" id="registration_tax_number" class="form-control" placeholder="<?php echo e(__('registration.registration_tax_number')); ?>" required>
                        </div>
                        <div class="form-group pb-3 input-icon">
                            <i class="fas fa-globe"></i>
                            <select name="country_id" id="country_id" class="form-control" required>
                                <option value=""><?php echo e(__('registration.country')); ?></option>
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($country['id']); ?>"><?php echo e(__($country['name'])); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group pb-3 input-icon">
                            <i class="fas fa-map-marker-alt"></i>
                            <input type="text" name="state" id="state" class="form-control" placeholder="<?php echo e(__('registration.state')); ?>" required>
                        </div>
                        <div class="form-group pb-3 input-icon">
                            <i class="fas fa-city"></i>
                            <input type="text" name="city" id="city" class="form-control" placeholder="<?php echo e(__('registration.city')); ?>" required>
                        </div>

                        <div class="form-group pb-3 input-icon">
                            <i class="fas fa-phone"></i>
                            <div class="d-flex">
                                <select name="phone_code" id="phone_code" class="form-control" style="max-width: 100px; margin-right: 10px;" required disabled>
                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($country['phone_code']); ?>"><?php echo e($country['phone_code']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <input type="text" name="mobile" id="mobile" class="form-control" placeholder="<?php echo e(__('registration.mobile')); ?>" required>
                            </div>
                        </div>
                        
                        
                        <div class="form-group pb-3 input-icon">
                            <i class="fas fa-lock"></i>
                            <input type="password" name="password" id="password" class="form-control" placeholder="<?php echo e(__('registration.password')); ?>" required>
                        </div>
                        <div class="form-group pb-3 input-icon">
                            <i class="fas fa-lock"></i>
                            <input type="password" name="password_confirmation" id="password_confirmation" class="form-control" placeholder="<?php echo e(__('registration.password_confirmation')); ?>" required>
                        </div>
                        <div class="form-group pb-3">
                            <div id="map"></div>
                            <input class="d-none" name="latitude" id="latitude">
                            <input class="d-none" name="longitude" id="longitude">
                        </div>
                        
                        <button type="submit" class="btn btn-primary btn-block"><i class="fas fa-user-plus"></i> <?php echo e(__('registration.register')); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(env('MAP_KEY')); ?>"></script>
<script>
    $(document).ready(function() {
        $('#country_id').select2({
            placeholder: "<?php echo e(__('registration.country')); ?>",
            allowClear: true
        });

        $('#country_id').on('change', function() {
            var selectedCountryId = $(this).val();
            var selectedCountry = <?php echo json_encode($countries, 15, 512) ?>.find(country => country.id == selectedCountryId);
            if (selectedCountry) {
                $('#phone_code').val(selectedCountry.phone_code);
            }
        });

        // Initialize Google Map
        var map;
        var marker;
        var latitude = document.getElementById('latitude');
        var longitude = document.getElementById('longitude');

        function initMap() {
            map = new google.maps.Map(document.getElementById('map'), {
                center: {lat: -34.397, lng: 150.644},
                zoom: 6
            });

            marker = new google.maps.Marker({
                map: map,
                draggable: true,
                position: {lat: -34.397, lng: 150.644}
            });

            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) {
                    var pos = {
                        lat: position.coords.latitude,
                        lng: position.coords.longitude
                    };
                    map.setCenter(pos);
                    marker.setPosition(pos);
                    latitude.value = pos.lat;
                    longitude.value = pos.lng;
                    updateLocationField(pos.lat, pos.lng);
                });
            }

            google.maps.event.addListener(marker, 'dragend', function() {
                var pos = marker.getPosition();
                latitude.value = pos.lat();
                longitude.value = pos.lng();
                updateLocationField(pos.lat(), pos.lng());
            });

            function updateLocationField(lat, lng) {
                var geocoder = new google.maps.Geocoder();
                var latlng = new google.maps.LatLng(lat, lng);
                geocoder.geocode({'location': latlng}, function(results, status) {
                    if (status === 'OK') {
                        if (results[0]) {
                            google_location.value = results[0].formatted_address;
                        }
                    }
                });
            }
        }

        initMap();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\CarCareHub\resources\views/company/register.blade.php ENDPATH**/ ?>