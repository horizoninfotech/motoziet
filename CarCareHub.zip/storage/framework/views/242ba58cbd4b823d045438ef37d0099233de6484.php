

<?php $__env->startSection('title', 'Company Details'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Company Details</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h3><?php echo e($company->name); ?></h3>
    </div>
    <div class="card-body">
        <p><strong>Email:</strong> <?php echo e($company->email); ?></p>
        <p><strong>Mobile:</strong> <?php echo e($company->mobile); ?></p>
        <p><strong>Registration Tax Number:</strong> <?php echo e($company->registration_tax_number); ?></p>
        <p><strong>Country:</strong>
        <?php if($company->country): ?>
            <?php echo e($company->country->name); ?>

        <?php else: ?>
            <i class="fas fa-exclamation-circle"></i> No Country assigned
        <?php endif; ?>
    </p>
        <p><strong>State:</strong> <?php echo e($company->state); ?></p>
        <p><strong>City:</strong> <?php echo e($company->city); ?></p>

        <?php if($company->latitude && $company->longitude): ?>
            <h4>Location</h4>
            <div id="map" style="height: 300px;"></div>
        <?php else: ?>
            <p><strong>Location:</strong> Not available</p>
        <?php endif; ?>
    </div>
    <div class="card-footer">
        <a href="<?php echo e(route('admin.companies.pending')); ?>" class="btn btn-primary">Back to List</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php if($company->latitude && $company->longitude): ?>
    <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(env('MAP_KEY')); ?>"></script>
    <script>
        function initMap() {
            var location = { lat: parseFloat('<?php echo e($company->latitude); ?>'), lng: parseFloat('<?php echo e($company->longitude); ?>') };
            var map = new google.maps.Map(document.getElementById('map'), {
                zoom: 14,
                center: location
            });
            var marker = new google.maps.Marker({
                position: location,
                map: map
            });
        }
        initMap();
    </script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\CarCareHub\resources\views/admin/companies/show.blade.php ENDPATH**/ ?>