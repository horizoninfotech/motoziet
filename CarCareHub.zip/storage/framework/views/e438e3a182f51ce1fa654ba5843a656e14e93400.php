

<?php $__env->startSection('title', 'Packages'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Packages</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('admin.packages.create')); ?>" class="btn btn-success mb-3">
    <i class="fas fa-plus-circle"></i> Add New Package
</a>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>Name</th>
            <th>Description</th>
            <th>Image</th>
            <th>Price</th>
            <th>Created At</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($package->name); ?></td>
                <td><?php echo e($package->description); ?></td>
                <td><img src="<?php echo e(asset('images/packages/' . $package->image)); ?>" alt="Image" width="50"></td>
                <td><?php echo e($package->price); ?></td>
                <td><?php echo e($package->created_at); ?></td>
                <td>
                    <a href="<?php echo e(route('admin.packages.show', $package->id)); ?>" class="btn btn-info btn-sm" title="View">
                        <i class="fas fa-eye"></i>
                    </a>
                    <a href="<?php echo e(route('admin.packages.edit', $package->id)); ?>" class="btn btn-warning btn-sm" title="Edit">
                        <i class="fas fa-edit"></i>
                    </a>
                    <button type="button" class="btn btn-danger btn-sm" title="Delete"
                            data-toggle="modal" data-target="#deleteModal" data-url="<?php echo e(route('admin.packages.destroy', $package->id)); ?>">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Confirm Deletion</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Are you sure you want to delete this package? This action cannot be undone.
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirmDelete">Delete</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript">
    $(document).ready(function() {
        var deleteUrl = '';

        $('#deleteModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            deleteUrl = button.data('url');
        });

        $('#confirmDelete').on('click', function() {
            var form = $('<form>', {
                'method': 'POST',
                'action': deleteUrl
            });

            var token = $('<input>', {
                'type': 'hidden',
                'name': '_token',
                'value': '<?php echo e(csrf_token()); ?>'
            });

            var hiddenInput = $('<input>', {
                'type': 'hidden',
                'name': '_method',
                'value': 'DELETE'
            });

            form.append(token, hiddenInput).appendTo('body').submit();
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\CarCareHub\resources\views/admin/packages/index.blade.php ENDPATH**/ ?>