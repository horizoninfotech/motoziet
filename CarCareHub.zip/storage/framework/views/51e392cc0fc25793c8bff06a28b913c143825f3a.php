

<?php $__env->startSection('title', 'Create Package'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Create Package</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-3">
    <a href="<?php echo e(route('admin.packages.index')); ?>" class="btn btn-secondary">
        <i class="fas fa-list"></i> View All Packages
    </a>
    <a href="<?php echo e(route('admin.packages.create')); ?>" class="btn btn-warning">
        <i class="fas fa-redo"></i> Clear Form
    </a>
</div>

<form action="<?php echo e(route('admin.packages.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="name">Name</label>
        <input type="text" name="name" class="form-control" id="name" placeholder="Enter package name" required>
    </div>
    <div class="form-group">
        <label for="description">Description</label>
        <textarea name="description" class="form-control" id="description" placeholder="Enter description"></textarea>
    </div>
    <div class="form-group">
        <label for="price">Price</label>
        <input type="number" name="price" class="form-control" id="price" placeholder="Enter price" required>
    </div>
    <div class="form-group">
        <label for="image">Image</label>
        <input type="file" name="image" class="form-control-file" id="image" required>
    </div>
    <button type="submit" class="btn btn-success">
        <i class="fas fa-save"></i> Create Package
    </button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\CarCareHub\resources\views/admin/packages/create.blade.php ENDPATH**/ ?>