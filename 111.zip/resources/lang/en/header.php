<?php

return [
    'home' => 'Home',
    'services' => 'Services',
    'packages' => 'Packages',
    'about_us' => 'About Us',
    'contact_us' => 'Contact Us',
    'login_register' => 'Login / Register',
    'get_support' => 'Get Support',
    'my_account' => 'My Account',
    'wishlist' => 'Wishlist',
    'shopping_cart' => 'Shopping Cart',
    'cart' => 'Cart',
    'subtotal' => 'Subtotal',
    'view_cart' => 'View Cart',
    'checkout' => 'Checkout',
    'free_shipping' => 'Free Shipping on All Orders Over $100!',
];
