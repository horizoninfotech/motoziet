<?php 
return [
    'title' => 'Company Registration',
    'name' => 'Company Name',
    'email' => 'Email',
    'mobile' => 'Mobile',
    'registration_tax_number' => 'Registration Tax Number',
    'country' => 'Select a country',
    'state' => 'State',
    'city' => 'City',
    'password' => 'Password',
    'password_confirmation' => 'Confirm Password',
    'register' => 'Register',
];