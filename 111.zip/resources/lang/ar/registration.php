<?php
return [
    'title' => 'تسجيل الشركة',
    'name' => 'اسم الشركة',
    'email' => 'البريد الإلكتروني',
    'mobile' => 'رقم الهاتف',
    'registration_tax_number' => 'الرقم الضريبي',
    'country' => 'اختر دولة',
    'state' => 'الولاية',
    'city' => 'المدينة',
    'password' => 'كلمة المرور',
    'password_confirmation' => 'تأكيد كلمة المرور',
    'register' => 'تسجيل',
];