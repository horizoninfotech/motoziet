@extends('layouts.main')

@section('title', 'Home Page')

@section('css')
    <!-- Add any page-specific CSS here -->
@endsection

@section('content')
<div class="body-wrapper">

 

</div>
    <!-- Add more content here -->
@endsection

@section('js')
    <!-- Add any page-specific JS here -->
@endsection