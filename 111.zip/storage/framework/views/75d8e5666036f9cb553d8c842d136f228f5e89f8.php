

<?php $__env->startSection('title', 'Country Details'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Country Details</h1>
    <a href="<?php echo e(route('admin.countries.index')); ?>" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Back to List
    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h3><?php echo e($country->name); ?></h3>
    </div>
    <div class="card-body">
        <p><strong>Name (Arabic):</strong> <?php echo e($country->name_ar); ?></p>
        <p><strong>Name (Urdu):</strong> <?php echo e($country->name_ur); ?></p>
        <p><strong>ISO Code:</strong> <?php echo e($country->iso_code); ?></p>
        <p><strong>Phone Code:</strong> <?php echo e($country->phone_code); ?></p>
        <p><strong>Created At:</strong> <?php echo e($country->created_at); ?></p>
        <p><strong>Updated At:</strong> <?php echo e($country->updated_at); ?></p>
    </div>
    <div class="card-footer">
        <a href="<?php echo e(route('admin.countries.edit', $country->id)); ?>" class="btn btn-warning">
            <i class="fas fa-edit"></i> Edit
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\CarCareHub\resources\views/admin/countries/show.blade.php ENDPATH**/ ?>