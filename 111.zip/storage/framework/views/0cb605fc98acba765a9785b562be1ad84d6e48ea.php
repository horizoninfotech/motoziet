

<?php $__env->startSection('title', 'Home Page'); ?>

<?php $__env->startSection('css'); ?>
    <!-- Add any page-specific CSS here -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="body-wrapper">

 

</div>
    <!-- Add more content here -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- Add any page-specific JS here -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\CarCareHub\resources\views/index.blade.php ENDPATH**/ ?>