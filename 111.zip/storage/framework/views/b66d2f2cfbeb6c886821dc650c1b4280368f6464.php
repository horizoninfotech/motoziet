

<?php $__env->startSection('title', __('auth.register_your_account')); ?>

<?php $__env->startSection('content'); ?>
<!-- BREADCRUMB AREA START -->
<?php
    $dir = in_array(app()->getLocale(), ['ar', 'ur']) ? 'rtl' : 'ltr';
?>
<div class="ltn__breadcrumb-area ltn__breadcrumb-area-2 ltn__breadcrumb-color-white bg-overlay-theme-black-90 bg-image" data-bs-bg="img/bg/9.jpg" dir="<?php echo e($dir); ?>">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="ltn__breadcrumb-inner ltn__breadcrumb-inner-2 justify-content-between">
                    <div class="section-title-area ltn__section-title-2">
                        <h6 class="section-subtitle ltn__secondary-color">//  <?php echo e(__('auth.welcome_message')); ?></h6>
                        <h1 class="section-title white-color"><?php echo e(__('auth.account')); ?></h1>
                    </div>
                    <div class="ltn__breadcrumb-list">
                        <ul>
                            <li><a href="index.html"><?php echo e(__('auth.home')); ?></a></li>
                            <li><?php echo e(__('auth.register')); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- BREADCRUMB AREA END -->

<!-- LOGIN AREA START (Register) -->
<?php
    $dir = in_array(app()->getLocale(), ['ar', 'ur']) ? 'rtl' : 'ltr';
?>
<div class="ltn__login-area pb-110"  dir="<?php echo e($dir); ?>">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-title-area text-center">
                    <h1 class="section-title"><?php echo e(__('auth.register')); ?> <br><?php echo e(__('auth.register_your_account')); ?></h1>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6 offset-lg-3">
                <div class="account-login-inner">
                    <form action="<?php echo e(route('register')); ?>" method="POST" class="ltn__form-box contact-form-box">
                        <?php echo csrf_field(); ?>  <!-- This will generate the CSRF token input field -->
                    
                        <input type="text" name="firstname" placeholder="<?php echo e(__('auth.first_name')); ?>" value="<?php echo e(old('firstname')); ?>">
                        <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    
                        <input type="text" name="lastname" placeholder="<?php echo e(__('auth.last_name')); ?>" value="<?php echo e(old('lastname')); ?>">
                        <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    
                        <input type="text" name="email" placeholder="<?php echo e(__('auth.email')); ?>" value="<?php echo e(old('email')); ?>">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    
                        <input type="password" name="password" placeholder="<?php echo e(__('auth.password')); ?>">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    
                        <input type="password" name="password_confirmation" placeholder="<?php echo e(__('auth.confirm_password')); ?>">
                        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    
                        <label class="checkbox-inline">
                            <input type="checkbox" value="">
                            <?php echo e(__('auth.privacy_consent')); ?>

                        </label>
                    
                        <div class="btn-wrapper">
                            <button class="theme-btn-1 btn reverse-color btn-block" type="submit"><?php echo e(__('auth.create_account')); ?></button>
                        </div>
                    
                        <!-- Google Login Button -->
                        <div class="btn-wrapper mt-3">
                            <a href="<?php echo e(route('google.login')); ?>" class="btn btn-danger btn-block">
                                <i class="fab fa-google"></i> <?php echo e(__('auth.google_signup')); ?>

                            </a>
                        </div>
                    </form>
                    
                    <div class="by-agree text-center">
                        <p><?php echo e(__('auth.agree_terms')); ?></p>
                        <p><a href="#"><?php echo e(__('auth.terms_conditions')); ?>  &nbsp; &nbsp; | &nbsp; &nbsp;  <?php echo e(__('auth.privacy_policy')); ?></a></p>
                        <div class="go-to-btn mt-50">
                            <a href="login.html"><?php echo e(__('auth.already_have_account')); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- LOGIN AREA END -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\CarCareHub\resources\views/register.blade.php ENDPATH**/ ?>