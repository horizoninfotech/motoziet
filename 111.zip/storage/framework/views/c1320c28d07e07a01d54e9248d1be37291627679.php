

<?php $__env->startSection('title', 'Manage Services for ' . $company->name); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Manage Services for <?php echo e($company->name); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<div class="row">
    <div class="col-md-6">
        <h4>Assigned Services</h4>
        <ul id="assigned-services" class="list-group">
            <?php $__currentLoopData = $company->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item" data-id="<?php echo e($service->id); ?>">
                    <?php echo e($service->title); ?>

                    <span class="float-right">
                        <button type="button" class="btn btn-danger btn-sm remove-service" title="Remove Service">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </span>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <div class="col-md-6">
        <h4>Available Services</h4>
        <ul id="available-services" class="list-group">
            <?php $__currentLoopData = $availableServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item" data-id="<?php echo e($service->id); ?>">
                    <?php echo e($service->title); ?>

                    <span class="float-right">
                        <button type="button" class="btn btn-success btn-sm assign-service" title="Assign Service">
                            <i class="fas fa-plus"></i>
                        </button>
                    </span>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function() {
        // Remove service
        $('.remove-service').on('click', function() {
            var serviceId = $(this).closest('li').data('id');
            var url = '<?php echo e(route("admin.companies.services.remove", ["company" => $company->id])); ?>';

            $.post(url, {
                _token: '<?php echo e(csrf_token()); ?>',
                service_id: serviceId
            }, function(response) {
                location.reload();
            });
        });

        // Assign service
        $('.assign-service').on('click', function() {
            var serviceId = $(this).closest('li').data('id');
            var url = '<?php echo e(route("admin.companies.services.assign", ["company" => $company->id])); ?>';

            $.post(url, {
                _token: '<?php echo e(csrf_token()); ?>',
                service_id: serviceId
            }, function(response) {
                location.reload();
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\CarCareHub\resources\views/admin/companies/services.blade.php ENDPATH**/ ?>