

<?php $__env->startSection('title', 'Rejected Companies'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Rejected Companies</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<form method="GET" action="<?php echo e(route('admin.companies.rejected')); ?>" class="mb-4">
    <div class="input-group">
        <input type="text" name="search" class="form-control" placeholder="Search for companies..." value="<?php echo e(request('search')); ?>">
        <span class="input-group-append">
            <button type="submit" class="btn btn-primary">Search</button>
        </span>
    </div>
</form>

<?php if($companies->isEmpty()): ?>
    <p>No companies have been rejected yet.</p>
<?php else: ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Company</th>
                <th>Email</th>
                <th>Mobile</th>
                <th>TRN</th>
                <th>Country</th>
                <th>State</th>
                <th>City</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($company->name); ?></td>
                    <td><?php echo e($company->email); ?></td>
                    <td><?php echo e($company->mobile); ?></td>
                    <td><?php echo e($company->registration_tax_number); ?></td>
                    <td><?php echo e($company->country->name); ?></td>
                    <td><?php echo e($company->state); ?></td>
                    <td><?php echo e($company->city); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.companies.show', $company->id)); ?>" class="btn btn-warning btn-sm" title="view" title="View">
                            <i class="fas fa-eye"></i> 
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="d-flex justify-content-center">
        <?php echo e($companies->appends(['search' => request('search')])->links('pagination::bootstrap-4')); ?>

    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\CarCareHub\resources\views/admin/companies/rejected.blade.php ENDPATH**/ ?>